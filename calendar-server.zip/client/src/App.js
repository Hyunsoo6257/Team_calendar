import Calendar from "../src/components/Calendar";
import Popup from "./components/Popup";
function App() {
  return (
    <div className="App">
      <Calendar />
    </div>
  );
}

export default App;
